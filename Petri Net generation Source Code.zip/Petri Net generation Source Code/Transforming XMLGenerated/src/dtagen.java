import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import java.util.*;

public class dtagen {
    static String fileName = "dtagen.txt";

    public static int findLocations(String currentId, Document document, NodeList arcList, Set<String> visitedNodes, List<String> locations, int locationCount, Map<String, String> locationMapping, Set<String> finalLocations) {
        for (int i = 0; i < arcList.getLength(); i++) {
            Node arcNode = arcList.item(i);
            if (arcNode.getNodeType() == Node.ELEMENT_NODE) {
                Element arcElement = (Element) arcNode;
                String sourceId = arcElement.getAttribute("source");
                String targetId = arcElement.getAttribute("target");

                if (!targetId.contains("Obstruct") && currentId.equals(sourceId) && visitedNodes.add(targetId)) {
                    if (!"Idle".equals(targetId)) {
                        if (!currentId.contains("transit") && !currentId.contains("Idle") && !targetId.contains("Idletransit")) {
                            locations.add("Intermediate Location --> L" + locationCount + " (" + currentId + ")");
                            locationMapping.put(currentId, "L" + locationCount);
                            locationCount++;
                        }
                        if (targetId.contains("Idletransit")) {
                            locations.add("Final Location --> L" + locationCount + " (" + sourceId + ")");
                            locationMapping.put(sourceId, "L" + locationCount);
                            finalLocations.add(sourceId); // Add to final locations
                            locationCount++;
                        }
                        locationCount = findLocations(targetId, document, arcList, visitedNodes, locations, locationCount, locationMapping, finalLocations);
                    }
                } else if (targetId.contains("Obstruct") && currentId.equals(sourceId) && visitedNodes.add(targetId) && !"Idle".equals(targetId)) {
                    // Check if the current node is a final location
                    if (!currentId.contains("transit") && !currentId.contains("Idle") && !finalLocations.contains(currentId)) {
                        locations.add("Context Location --> L" + locationCount + " (" + targetId + ")");
                        locationMapping.put(targetId, "L" + locationCount); // Corrected to targetId
                        locationCount++;
                    }
                }
            }
        }
        return locationCount;
    }

    public static void countEdgesAndWriteToFile(String fileName, List<String> locations, Map<String, String> locationMapping) {
        try {
            List<String> edges = new ArrayList<>();
            String prevLocation = "L0";
            Map<String, String> contextToNewLocation = new HashMap<>();

            for (String currentLine : locations) {
                String[] parts = currentLine.split(" ");

                if (parts.length < 5) {
                    continue; // Skip lines that do not have enough parts
                }

                if (currentLine.startsWith("Initial Location")) {
                    prevLocation = "L0";
                } else if (currentLine.startsWith("Intermediate Location") || currentLine.startsWith("Final Location")) {
                    String currentLocation = parts[4].replace("(", "").replace(")", "");
                    String currentLocationLabel = locationMapping.getOrDefault(currentLocation, currentLocation);

                    // Add the edge from previous to current location
                    edges.add(prevLocation + " ---> " + currentLocationLabel);

                    // Check for matching context location
                    for (String contextLine : locations) {
                        if (contextLine.startsWith("Context Location")) {
                            String contextLocation = contextLine.split(" ")[4].replace("(", "").replace(")", "");
                            String contextLocationLabel = locationMapping.getOrDefault(contextLocation, contextLocation);

                            // Check if the current location is the source of the context location
                            if (contextLocation.startsWith(currentLocation + "Obstruct")) {
                                // Create new location for the context if not already created
                                if (!contextToNewLocation.containsKey(contextLocationLabel)) {
                                    String newLocationLabel = contextLocationLabel + "'"; // Append prime symbol

                                    contextToNewLocation.put(contextLocationLabel, newLocationLabel);

                                    // Add edges
                                    edges.add(currentLocationLabel + " ---> " + contextLocationLabel);
                                    edges.add(contextLocationLabel + " ---> " + newLocationLabel);
                                    edges.add(newLocationLabel + " ---> " + currentLocationLabel);
                                }
                            }
                        }
                    }

                    if (currentLine.startsWith("Final Location")) {
                        prevLocation = "L0"; // Reset to initial location after a final location
                    } else {
                        prevLocation = currentLocationLabel;
                    }
                }
            }

            FileWriter writer = new FileWriter(fileName);
            writer.write("DTA WorkNetDTA = {\n");
            writer.write("\tLOCATIONS = {\n");
            for (String location : locations) {
                writer.write("\t\t" + location + "\n");
            }

            // Write new context locations
            for (Map.Entry<String, String> entry : contextToNewLocation.entrySet()) {
                writer.write("\t\tContext Location --> " + entry.getValue() + " (" + entry.getKey() + ")\n");
            }

            writer.write("\t}\n\n");

            writer.write("\tEDGES = {\n");
            for (String edge : edges) {
                writer.write("\t\t" + edge + "\n");
            }
            writer.write("\t}\n");

            writer.write("}\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse("tempoutput.pnml");
            document.getDocumentElement().normalize();

            Set<String> visitedNodes = new HashSet<>();
            int locationCount = 1;
            Map<String, String> locationMapping = new HashMap<>();
            locationMapping.put("Idle", "L0");

            List<String> locations = new ArrayList<>();
            Set<String> finalLocations = new HashSet<>(); // Set to store final locations
            locations.add("Initial Location --> L0 (Idle)");

            NodeList arcList = document.getElementsByTagName("arc");

            locationCount = findLocations("Idle", document, arcList, visitedNodes, locations, locationCount, locationMapping, finalLocations);

            // Count edges and write to file
            countEdgesAndWriteToFile(fileName, locations, locationMapping);

            System.out.println("Check complete");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
