import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class RefactorXML {
	static String[] placelist=new String[500];
	static int placelistindex=0;
	static String[] transitionlist= new String[500];
	static int transitionlistindex=0;
	static String[] arclist=new String[500];
	static int arclistindex=0;
	static String fileoutput= "GenPNMLCreate3_1a.pnml";
	static String fileinput= "PNMLsystemCreate3_1a.xmi";
	static String fileCTL="CTL.txt";
	static String fileCTLoutput="ResultCTL.txt";
	static String [][] connfr= new String[500][2];
	static String [][] tasknfr= new String[500][2];
	static String [][] taskcontext=new String[500][2];
	static int index1=0, index2=0,index3=0;
	static int arcid=1;
	public static void create_file() {
		try {
		FileWriter fw = new FileWriter(fileoutput, false); 
		BufferedWriter bw = new BufferedWriter(fw);
		//Writing Initial Texts
		bw.write("<?xml version=\"1.0\"?>");
		bw.newLine();
		bw.write("<pnml xmlns=\"http://www.pnml.org/version-2009/grammar/pnml\">");
		bw.newLine();
		bw.write("<!-- Written by GreatSPN Editor. -->");
		bw.newLine();
		bw.write("<net id=\"GSPN\" type=\"http://www.pnml.org/version-2009/grammar/ptnet\">");
		bw.newLine();
		bw.write("<name>");
		bw.newLine();
		bw.write("<text>GSPN</text>");
		bw.newLine();
		bw.write("</name>");
		bw.newLine();
		bw.write("<page id=\"page0\">");
		bw.newLine();
		bw.write("<name>");
		bw.newLine();
		bw.write("<text>DefaultPage</text>");
		bw.newLine();
		bw.write("</name>");
		bw.newLine();
		bw.write("<!-- List of places -->");
		bw.newLine();
		bw.close();
		}catch(IOException e) {
			System.out.println("Unable to Write into file the initial Texts");
		}
	}
	public static void group_places() {
		String fname="PNMLUpdated3.xmi";
		String[] placeidarray= new String[1000];
		int arrayindex=0;
		try {
		FileReader fread= new FileReader(fileinput);
		int i;
		char c;
		String temp="";
		int writeflag=0;
		//Reads original XMI file. Extracts places and writes it into new File.
		
		while((i=fread.read())!=-1) {
			temp="";
			c=(char)i;
			
			
			temp=temp.concat(Character.toString(c));
			while((i=fread.read())!=10) {
				if(i!=13) {
					c=(char)i;
					
					temp=temp.concat(Character.toString(c));
				}
			}
			//Now check if it is a place
			if(temp.contains("place") || temp.contains("Place")) {
				FileWriter fw = new FileWriter("temp.txt", false); 
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(temp);
				bw.newLine();
				int breakflag=0;
				while(breakflag==0) {
					temp="";
					while((i=fread.read())!=10) {
						if(i!=13) {
							c=(char)i;
							temp=temp.concat(Character.toString(c));
						}
				}
				if(temp.contains("/place") || temp.contains("/pNML:Place")) {
					breakflag=1;
				}
				else {
					bw.write(temp);
					bw.newLine();
				}
			}
			bw.close();
			writeflag=0;
			//Now read temp.txt file and insert it into PNML
			FileReader fread2= new FileReader("temp.txt");
			FileWriter fw2 = new FileWriter(fileoutput, true); 
			BufferedWriter bw2 = new BufferedWriter(fw2);
			int j=0;
			char c2;
			String temp2="";
			String id="";
			while((j=fread2.read())!=-1) {
				temp2="";
				c2=(char)j;
				temp2=temp2.concat(Character.toString(c2));
				while((j=fread2.read())!=10) {
					if(j!=13) {
					c2=(char)j;
					temp2=temp2.concat(Character.toString(c2));
					}
				}
				
				if((temp2.contains("place") || temp2.contains("Place")) && temp2.contains("id")) {
					//Extract the id
					int index=temp2.indexOf("id")+3;
					int breakflag2=0;
					id="";
					while(breakflag2==0) {
						if(temp2.charAt(index)=='>') {
							breakflag2=1;
						}
						else if(temp2.charAt(index)=='"') {
							//do nothing
						}
						else
							id=id.concat(Character.toString(temp2.charAt(index)));
						index++;
					}
					//Write the first line
					String placeid= "<place id=\""+id+"\">";
					placelist[placelistindex]=placeid;
					placelistindex++;
					if(arrayindex==0) {
					bw2.write(placeid);
					bw2.newLine();
					placeidarray[arrayindex]=placeid;
					arrayindex++;
					}
					else {
						int p=0;
						while(p<arrayindex) {
							if((placeid.compareTo(placeidarray[p]))==0)
								writeflag=1;
							p++;
						}
						
						if(writeflag==0) {
							bw2.write(placeid);
							bw2.newLine();
							placeidarray[arrayindex]=placeid;
							arrayindex++;
						}
					}
				}
				//Extract value
				else if(temp2.contains("initialmarking") && writeflag==0) {
					int index=temp2.indexOf("value")+6;
					int breakflag2=0;
					id="";
					while(breakflag2==0) {
						if(temp2.charAt(index)=='/') {
							breakflag2=1;
						}
						else if(temp2.charAt(index)=='"') {
							//do nothing
						}
						else
							id=id.concat(Character.toString(temp2.charAt(index)));
						index++;
					}
					//Write the  lines in format
					bw2.write("<initialMarking>");
					bw2.newLine();
					bw2.write("<text>"+id+"</text>");
					bw2.newLine();
					bw2.write("</initialMarking>");
					bw2.newLine();
				}
				else if(temp2.contains("/graphics") && writeflag==0) {
					bw2.write(temp2);
					bw2.newLine();
					bw2.write("<text>"+id+"</text>");
					bw2.newLine();
				}
				else if(writeflag==0) {
					bw2.write(temp2);
					bw2.newLine();
				}
					
				
			}
			if(writeflag==0) {
			bw2.write("</place>");
			bw2.newLine();
			}
			bw2.close();
			fread2.close();
		}
		}

		FileWriter fw = new FileWriter(fileoutput, true); 
		BufferedWriter bw = new BufferedWriter(fw);
		int r=0;
		while(r<index3) {
			String id= taskcontext[r][0]+"Obstruct"+taskcontext[r][1];
			String placeid= "<place id=\""+id+"\">";
			bw.write(placeid);
			bw.newLine();
			bw.write("<name>");
			bw.newLine();
		    bw.write("<graphics>");
			bw.newLine();
		    bw.write("<offset x=\"0.1\" y=\"15.0\"/>");
			bw.newLine();
		    bw.write("</graphics>");
			bw.newLine();
		    bw.write("<text>"+id+"</text>");
			bw.newLine();
		    bw.write("</name>");
			bw.newLine();
		    bw.write("</place>");
			bw.newLine();
			r++;
		}
		bw.close();
		fread.close();
		}catch(IOException e) {
			System.out.println("Unable to Open PNMLUpdated.xmi file for writing places");
		}
	}
	public static void find_missing_elements() {
	
		try {
		FileReader fread= new FileReader(fileinput);
		int i;
		char c;
		String temp="";
		while((i=fread.read())!=-1) {
			temp="";
			c=(char)i;
			if(i!=32)
				temp=temp.concat(Character.toString(c));
			while((i=fread.read())!=10) {
				if(i!=13 ) {
					c=(char)i;
					temp=temp.concat(Character.toString(c));
				}
			}
			//Now check if it is a arc
			if(temp.contains("arc") && temp.contains("AnyS")) {
			String source="";
			String target="";
			int breakflag2=0;
			int index=temp.indexOf("source")+7;
			breakflag2=0;
			while(breakflag2==0) {
				if(temp.charAt(index)==' ') {
					//do nothing
					breakflag2=1;
				}
				else if(temp.charAt(index)=='"') {
					//do nothing
					//breakflag2=1;
				}
				else
					source=source.concat(Character.toString(temp.charAt(index)));
				index++;
			}
		
			index=temp.indexOf("target")+7;
			breakflag2=0;
			while(breakflag2==0) {
				if(temp.charAt(index)=='/') {
					//do nothing
					breakflag2=1;
				}
				else if(temp.charAt(index)=='"') {
					//do nothing
					//breakflag2=1;
				}
				else
					target=target.concat(Character.toString(temp.charAt(index)));
				index++;
			}
			connfr[index1][0]=source;
			connfr[index1][1]=target;
			index1++;
		}
		else if(temp.contains("arc") && temp.contains("AnyT")) {
			String source="";
			String target="";
			int breakflag2=0;
			int index=temp.indexOf("source")+7;
			breakflag2=0;
			while(breakflag2==0) {
				if(temp.charAt(index)==' ') {
					//do nothing
					breakflag2=1;
				}
				else if(temp.charAt(index)=='"') {
					//do nothing
					//breakflag2=1;
				}
				else
					source=source.concat(Character.toString(temp.charAt(index)));
				index++;
			}
			index=temp.indexOf("target")+7;
			breakflag2=0;
			while(breakflag2==0) {
				if(temp.charAt(index)=='/') {
					//do nothing
					breakflag2=1;
				}
				else if(temp.charAt(index)=='"') {
					//do nothing
					//breakflag2=1;
				}
				else
					target=target.concat(Character.toString(temp.charAt(index)));
				index++;
			}
			tasknfr[index2][0]=source;
			tasknfr[index2][1]=target;
			index2++;
		}
		}
		fread.close();
		}catch(IOException e) {
			System.out.println("Unable to Open file for reading missing elements");
		}
		int p=0, q=0;
		while(p<index2) {
			String task=tasknfr[p][0];
			String nfr=tasknfr[p][1];
			String[] conlist=new String[100];
			q=0;
			while(q<index1) {
				String cnfr=connfr[q][1];
				String context=connfr[q][0];
				if(nfr.compareTo(cnfr)==0)
				{
					//Check if exist in conlist
					int r=0,flag=0;
					while(r<index3) {
						if(taskcontext[r][0].compareTo(task)==0) {
							if(taskcontext[r][1].compareTo(context)==0)
								flag=1;
						}
						r++;
					}
					if(flag==0) {
						taskcontext[index3][0]=task;
						taskcontext[index3][1]=context;
						index3++;
					}
				}
				q++;
			}
			p++;
		}
		int r=0;
		while(r<index3) {
			System.out.println("Task-context pair"+ taskcontext[r][0]+" -> "+taskcontext[r][1]);
			r++;
		}
	}
	public static void group_transitions() {
		
		String fname="PNMLUpdated3.xmi";
		String[] transitionidarray= new String[1000];
		int arrayindex=0;
		int writeflag=0;
		try {
		//Initial Statement
			FileWriter fw2 = new FileWriter(fileoutput, true); 
			BufferedWriter bw2 = new BufferedWriter(fw2);
			bw2.write("<!-- List of transitions -->");
			bw2.newLine();
			bw2.close();
		FileReader fread= new FileReader(fileinput);
		int i;
		char c;
		String temp="";
		//Reads original XMI file. Extracts transitions and writes it into new File.
		
		while((i=fread.read())!=-1) {
			temp="";
			c=(char)i;
			
			
			temp=temp.concat(Character.toString(c));
			while((i=fread.read())!=10) {
				if(i!=13) {
					c=(char)i;
					
					temp=temp.concat(Character.toString(c));
				}
			}
			//Now check if it is a transition
			if(temp.contains("transition")) {
				FileWriter fw = new FileWriter("temp.txt", false); 
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(temp);
				bw.newLine();
				int breakflag=0;
				while(breakflag==0) {
					temp="";
					while((i=fread.read())!=10) {
						if(i!=13) {
							c=(char)i;
							temp=temp.concat(Character.toString(c));
						}
				}
				if(temp.contains("/transition") || temp.contains("/pNML:transition")) {
					breakflag=1;
				}
				else {
					bw.write(temp);
					bw.newLine();
				}
			}
			bw.close();
			writeflag=0;
			//Now read temp.txt file and insert it into PNML
			FileReader fread2= new FileReader("temp.txt");
			fw2 = new FileWriter(fileoutput, true); 
			bw2 = new BufferedWriter(fw2);
			int j=0;
			char c2;
			String temp2="";
			String id="";
			while((j=fread2.read())!=-1) {
				temp2="";
				c2=(char)j;
				temp2=temp2.concat(Character.toString(c2));
				while((j=fread2.read())!=10) {
					if(j!=13) {
					c2=(char)j;
					temp2=temp2.concat(Character.toString(c2));
					}
				}
				
				if((temp2.contains("transition")) && temp2.contains("id")) {
					//Extract the id
					int index=temp2.indexOf("id")+3;
					int breakflag2=0;
					id="";
					while(breakflag2==0) {
						if(temp2.charAt(index)=='>' || temp2.charAt(index)==' ') {
							breakflag2=1;
						}
						else if(temp2.charAt(index)=='"') {
							//do nothing
						}
						else
							id=id.concat(Character.toString(temp2.charAt(index)));
						index++;
					}
					String type="";
					breakflag2=0;
					if(temp2.contains("type"))
					{
						index=temp2.indexOf("type")+6;
						while(breakflag2==0) {
							if(temp2.charAt(index)=='>') {
								breakflag2=1;
							}
							else if(temp2.charAt(index)=='"') {
								//do nothing
							}
							else
								type=type.concat(Character.toString(temp2.charAt(index)));
							index++;
						}
					
					}
					//Write the first line
					String transitionid= "<transition id=\""+id+"\">";
					transitionlist[transitionlistindex]=transitionid;
					transitionlistindex++;
					if(arrayindex==0) {
					bw2.write(transitionid);
					bw2.newLine();
					if(type.compareTo("")!=0) {
						bw2.write("<!-- Transition Type should be "+type+". -->");
						bw2.newLine();
					}
					else {
						bw2.write("<!-- Transition Type should be Exponential. -->");
						bw2.newLine();
					}
					transitionidarray[arrayindex]=transitionid;
					arrayindex++;
					}
					else {
						int p=0;
						while(p<arrayindex) {
							if((transitionid.compareTo(transitionidarray[p]))==0)
								writeflag=1;
							p++;
						}
						
						if(writeflag==0) {
							bw2.write(transitionid);
							bw2.newLine();
							if(type.compareTo("")!=0) {
								bw2.write("<!-- Transition Type should be "+type+". -->");
								bw2.newLine();
							}
							else {
								bw2.write("<!-- Transition Type should be Exponential. -->");
								bw2.newLine();
							}
							transitionidarray[arrayindex]=transitionid;
							arrayindex++;
						}
					}
				
					}
				else if(temp2.contains("/graphics") && writeflag==0) {
					bw2.write(temp2);
					bw2.newLine();
					bw2.write("<text>"+id+"</text>");
					bw2.newLine();
				}
				else if(writeflag==0) {
					bw2.write(temp2);
					bw2.newLine();
				}

			}
			if(writeflag==0) {
			bw2.write("</transition>");
			bw2.newLine();
			}
			bw2.close();
			fread2.close();
		}
		}
		fread.close();
		 fw2 = new FileWriter(fileoutput, true); 
		 bw2 = new BufferedWriter(fw2);
		 int r=0;
		 while(r<index3) {
			 String id= taskcontext[r][0]+"Obstruct"+taskcontext[r][1]+"transit";
			 String transitionid= "<transition id=\""+id+"\">";
			 bw2.write(transitionid);
			 bw2.newLine();
			 bw2.write("<!-- Transition Type should be Immediate. -->");
			 bw2.newLine();
			 bw2.write("<name>");
			 bw2.newLine();
			bw2.write("<graphics>");
			bw2.newLine();
			bw2.write("<offset x=\"0.1\" y=\"15.0\"/>");
			bw2.newLine();
			bw2.write("</graphics>");
			bw2.newLine();
			bw2.write("<text>"+id+"</text>");
			bw2.newLine();
			bw2.write(" </name>");
			bw2.newLine();
			bw2.write("</transition>");
			bw2.newLine();
			id= taskcontext[r][0]+taskcontext[r][1]+"transitclear";
			transitionid= "<transition id=\""+id+"\">";
			 bw2.write(transitionid);
			 bw2.newLine();
			 bw2.write("<!-- Transition Type should be General. -->");
			 bw2.newLine();
			 bw2.write("<name>");
			 bw2.newLine();
			bw2.write("<graphics>");
			bw2.newLine();
			bw2.write("<offset x=\"0.1\" y=\"15.0\"/>");
			bw2.newLine();
			bw2.write("</graphics>");
			bw2.newLine();
			bw2.write("<text>"+id+"</text>");
			bw2.newLine();
			bw2.write(" </name>");
			bw2.newLine();
			bw2.write("</transition>");
			bw2.newLine();
			 r++;
		 }
		bw2.close();
		}catch(IOException e) {
			System.out.println("Unable to Open PNMLUpdated.xmi file for writing transitions");
		}
	}
	public static void group_arcs() {
		String [][] connfr= new String[500][2];
		String [][] tasknfr= new String[500][2];
		int index1=0, index2=0;
		String fname="PNMLUpdated3.xmi";
		String[] arcidarray= new String[1000];
		int arrayindex=0;
		int writeflag=0;
		try {
		//Initial Statement
			FileWriter fw2 = new FileWriter(fileoutput, true); 
			BufferedWriter bw2 = new BufferedWriter(fw2);
			bw2.write("<!-- List of arcs -->");
			bw2.newLine();
			bw2.close();
		FileReader fread= new FileReader(fileinput);
		int i;
		char c;
		String temp="";
		//Reads original XMI file. Extracts arcs and writes it into new File.
		fw2 = new FileWriter(fileoutput, true); 
		bw2 = new BufferedWriter(fw2);
		while((i=fread.read())!=-1) {
			temp="";
			c=(char)i;
			if(i!=32)
				temp=temp.concat(Character.toString(c));
			while((i=fread.read())!=10) {
				if(i!=13 ) {
					c=(char)i;
					temp=temp.concat(Character.toString(c));
				}
			}
			//Now check if it is a arc
			writeflag=0;
			if(temp.contains("arc") && !temp.contains("Any")) {
				//System.out.println("Arc = "+temp);
				int size=temp.length();
				int k=0;
				String id="";
				String source="";
				String target="";
				int breakflag2=0;
				id="";
				int index=temp.indexOf("id")+3;
				while(breakflag2==0) {
					if(temp.charAt(index)==' ') {
						//do nothing
						breakflag2=1;
					}
					else
						id=id.concat(Character.toString(temp.charAt(index)));
					index++;
				}
				index=temp.indexOf("source")+7;
				breakflag2=0;
				while(breakflag2==0) {
					if(temp.charAt(index)==' ') {
						//do nothing
						breakflag2=1;
					}
					else
						source=source.concat(Character.toString(temp.charAt(index)));
					index++;
				}
				index=temp.indexOf("target")+7;
				breakflag2=0;
				while(breakflag2==0) {
					if(temp.charAt(index)=='/') {
						//do nothing
						breakflag2=1;
					}
					else
						target=target.concat(Character.toString(temp.charAt(index)));
					index++;
				}
				String arcid= "<arc source="+source+" target="+target+">";
				String arcid2= "<arc id="+id+" source="+source+" target="+target+">";
				arclist[arclistindex]=arcid2;
				arclistindex++;
				if(arrayindex==0) {
				bw2.write(arcid2);
				bw2.newLine();
				arcidarray[arrayindex]=arcid;
				arrayindex++;
				}
				else {
					int p=0;
					while(p<arrayindex) {
						if((arcid.compareTo(arcidarray[p]))==0)
							writeflag=1;
						p++;
					}
					if(writeflag==1) {
						//System.out.println("Writeflag enabled");
						//System.out.println("Arc matched= "+temp);
					}
					if(writeflag==0) {
						bw2.write(arcid2);
						bw2.newLine();
						arcidarray[arrayindex]=arcid;
						arrayindex++;
					}
				}
				
			if(writeflag==0) {
			bw2.write("</arc>");
			bw2.newLine();
			}
		
		}
		
		}
		bw2.close();
		fw2 = new FileWriter(fileoutput, true); 
		bw2 = new BufferedWriter(fw2);
		
		int r=0;
		while(r<index3) {
			String source=taskcontext[r][0];
			String target= taskcontext[r][0]+"Obstruct"+taskcontext[r][1]+"transit";
			String arcid2= "<arc id=\"OB"+arcid+"\" source=\""+source+"\" target=\""+target+"\">";
			bw2.write(arcid2);
			bw2.newLine();
			bw2.write("</arc>");
			bw2.newLine();
			arcid++;
			source="OnMove"+taskcontext[r][1];
			arcid2= "<arc id=\"OB"+arcid+"\" source=\""+source+"\" target=\""+target+"\">";
			bw2.write(arcid2);
			bw2.newLine();
			bw2.write("</arc>");
			bw2.newLine();
			arcid++;
			source= taskcontext[r][0]+"Obstruct"+taskcontext[r][1]+"transit";
			target= taskcontext[r][0]+"Obstruct"+taskcontext[r][1];
			arcid2= "<arc id=\"OB"+arcid+"\" source=\""+source+"\" target=\""+target+"\">";
			bw2.write(arcid2);
			bw2.newLine();
			bw2.write("</arc>");
			bw2.newLine();
			arcid++;
			source= taskcontext[r][0]+"Obstruct"+taskcontext[r][1];
			target= taskcontext[r][0]+taskcontext[r][1]+"transitclear";
			arcid2= "<arc id=\"OB"+arcid+"\" source=\""+source+"\" target=\""+target+"\">";
			bw2.write(arcid2);
			bw2.newLine();
			bw2.write("</arc>");
			bw2.newLine();
			arcid++;
			source= taskcontext[r][0]+taskcontext[r][1]+"transitclear";
			target= taskcontext[r][0];
			arcid2= "<arc id=\"OB"+arcid+"\" source=\""+source+"\" target=\""+target+"\">";
			bw2.write(arcid2);
			bw2.newLine();
			bw2.write("</arc>");
			bw2.newLine();
			arcid++;
			r++;
		}
		bw2.close();
		fread.close();
		}catch(IOException e) {
			System.out.println("Unable to Open PNMLUpdated.xmi file for writing arcs");
		}
	}
	public static void add_endlines() {
		try {
			FileWriter fw2 = new FileWriter(fileoutput, true); 
			BufferedWriter bw2 = new BufferedWriter(fw2);
			bw2.write("</page>");
			bw2.newLine();
			bw2.write("</net>");
			bw2.newLine();
			bw2.write("</pnml>");
			bw2.newLine();
			bw2.close();
			}catch(IOException e) {
				
			}
	}
	public static void CTL_generation() {
		int index1,index2 ;
		System.out.println("Place Count "+placelistindex);
		System.out.println("Transition Count "+transitionlistindex);
		try {
			FileWriter fw2 = new FileWriter(fileCTL, false); 
			BufferedWriter bw2 = new BufferedWriter(fw2);
			FileWriter fw3 = new FileWriter(fileCTLoutput, false); 
			BufferedWriter bw3 = new BufferedWriter(fw3);
			//Writing Deadlock property
			bw2.write("Type = Deadlock");
			bw2.newLine();
			bw2.write("Category = Initial Places");
			bw2.newLine();
			bw2.write("Expected Output = False");
			bw2.newLine();
			bw2.write("Output = True Inference = Deadlock exists");
			bw2.newLine();
			bw2.write("EF(#Idle==0 && #Tasks>0)");
			bw2.newLine();
			bw2.newLine();
			bw2.newLine();
			bw3.write("Property: EF(#Idle==0 && #Tasks>0)");
			bw3.newLine();
			bw3.write("Output:");
			bw3.newLine();
			bw3.write("Trace:");
			bw3.newLine();
			//Writing Resource Conflict property
			//First find duplicate places
			index1=0;
			int wflag=0;
			while(index1<placelistindex) {
				index2=index1+1;
				while(index2<placelistindex) {
					if(placelist[index1].compareTo(placelist[index2])==0) {
						//Duplicate
						//Extract the id
						int loc=placelist[index1].indexOf("id")+3;
						int breakflag=0;
						String id="";
						while(breakflag==0) {
							if(placelist[index1].charAt(loc)=='>') {
								breakflag=1;
							}
							else if(placelist[index1].charAt(loc)=='"') {
								//do nothing
							}
							else
								id=id.concat(Character.toString(placelist[index1].charAt(loc)));
							loc++;
						}
						if(!id.contains("Obstruct") && !id.contains("obstruct") &&  !id.contains("Collision") && !id.contains("collision")) {
							//Write the property
							if(wflag==0) {
								bw2.write("Type = Boundedness");
								bw2.newLine();
								bw2.write("Category = Shared Resource");
								bw2.newLine();
								bw2.write("Expected Output = False");
								bw2.newLine();
								bw2.write("Output = True Inference = Conflict Exists");
								bw2.newLine();
								wflag=1;
							}
							bw2.write("EF(#"+id+">2)");
							bw2.newLine();
							bw2.newLine();
							bw2.newLine();
							bw3.write("Property: EF(#"+id+">2)");
							bw3.newLine();
							bw3.write("Output:");
							bw3.newLine();
							bw3.write("Trace:");
							bw3.newLine();
						}
					}
					index2++;
				}
				index1++;
			}
			//Liveness property for final state
			//Extract the final places from arc info
			String[] finalplacelist=new String[500];
			int finalplacelistindex=0;
			index1=0;
			String prop= "";
			while(index1<arclistindex) {
				//Check if any arc has target as idle-
				//Extract the target
				int loc=arclist[index1].indexOf("target")+7;
				int breakflag=0;
				String target="";
				while(breakflag==0) {
					if(arclist[index1].charAt(loc)=='>') {
						breakflag=1;
					}
					else if(arclist[index1].charAt(loc)=='"') {
						//do nothing
					}
					else
						target=target.concat(Character.toString(arclist[index1].charAt(loc)));
					loc++;
				}
				
				if(target.compareTo("Idle")==0) {
					//Now extract the source
					loc=arclist[index1].indexOf("source")+7;
					breakflag=0;
					String source="";
					while(breakflag==0) {
						if(arclist[index1].charAt(loc)==' ') {
							breakflag=1;
						}
						else if(arclist[index1].charAt(loc)=='"') {
							//do nothing
						}
						else
							source=source.concat(Character.toString(arclist[index1].charAt(loc)));
						loc++;
					}
					//Now get another source that is the final task point whose target is the source found above
					index2=0;
					if(!source.contains("Obstruct") && !source.contains("obstruct")) {
					while(index2<arclistindex) {
						loc=arclist[index2].indexOf("target")+7;
						breakflag=0;
						 target="";
						while(breakflag==0) {
							if(arclist[index2].charAt(loc)=='>') {
								breakflag=1;
							}
							else if(arclist[index2].charAt(loc)=='"') {
								//do nothing
							}
							else
								target=target.concat(Character.toString(arclist[index2].charAt(loc)));
							loc++;
						}
						//System.out.println("Target 2= "+target);
						if(target.compareTo(source)==0) {
							//Found It
							loc=arclist[index2].indexOf("source")+7;
							breakflag=0;
							 source="";
							while(breakflag==0) {
								if(arclist[index2].charAt(loc)==' ') {
									breakflag=1;
								}
								else if(arclist[index2].charAt(loc)=='"') {
									//do nothing
								}
								else
									source=source.concat(Character.toString(arclist[index2].charAt(loc)));
								loc++;
							}
							finalplacelist[finalplacelistindex]=source;
							finalplacelistindex++;
						}
						index2++;
					}
				}
				}
				index1++;
			}
			int k=0;
			while(k<finalplacelistindex) {
				if((k+1)==finalplacelistindex)
					prop=prop.concat("EF(#"+finalplacelist[k]+">0)");
				else
					prop=prop.concat("EF(#"+finalplacelist[k]+">0) && ");
				k++;
			}
			bw2.write("Type = Liveness");
			bw2.newLine();
			bw2.write("Category = Tasks completion");
			bw2.newLine();
			bw2.write("Expected Output = True");
			bw2.newLine();
			bw2.write("Output = False Inference = Tasks failed to complete");
			bw2.newLine();
			bw2.write(prop);
			bw2.newLine();
			bw2.newLine();
			bw2.newLine();
			bw3.write("Property: "+ prop);
			bw3.newLine();
			bw3.write("Output:");
			bw3.newLine();
			bw3.write("Trace:");
			bw3.newLine();
			//CTL Property to check tasks initiated at same time
			//Obtain the initial task places
			String[] firstplacelist=new String[500];
			int firstplacelistindex=0;
			index1=0;
			prop= "";
			while(index1<arclistindex) {
				//Check if any arc has target as idle-
				//Extract the target
				int loc=arclist[index1].indexOf("source")+7;
				int breakflag=0;
				String source="";
				while(breakflag==0) {
					if(arclist[index1].charAt(loc)==' ') {
						breakflag=1;
					}
					else if(arclist[index1].charAt(loc)=='"') {
						//do nothing
					}
					else
						source=source.concat(Character.toString(arclist[index1].charAt(loc)));
					loc++;
				}
				
				if(source.compareTo("Idle")==0) {
					//System.out.println("Source = "+source);
					//Now extract the source
					loc=arclist[index1].indexOf("target")+7;
					breakflag=0;
					String target="";
					while(breakflag==0) {
						if(arclist[index1].charAt(loc)=='>') {
							breakflag=1;
						}
						else if(arclist[index1].charAt(loc)=='"') {
							//do nothing
						}
						else
							target=target.concat(Character.toString(arclist[index1].charAt(loc)));
						loc++;
					}
					//System.out.println("Target = "+target);
					//Now get another source that is the final task point whose target is the source found above
					index2=0;
					if(!target.contains("Obstruct") && !target.contains("obstruct")) {
					while(index2<arclistindex) {
						loc=arclist[index2].indexOf("source")+7;
						breakflag=0;
						 source="";
						while(breakflag==0) {
							if(arclist[index2].charAt(loc)==' ') {
								breakflag=1;
							}
							else if(arclist[index2].charAt(loc)=='"') {
								//do nothing
							}
							else
								source=source.concat(Character.toString(arclist[index2].charAt(loc)));
							loc++;
						}
						//System.out.println("Target 2= "+target);
						if(target.compareTo(source)==0) {
							//System.out.println("Source matched "+source+" with "+arclist[index2]);
							//Found It
							loc=arclist[index2].indexOf("target")+7;
							breakflag=0;
							 target="";
							while(breakflag==0) {
								if(arclist[index2].charAt(loc)=='>') {
									breakflag=1;
								}
								else if(arclist[index2].charAt(loc)=='"') {
									//do nothing
								}
								else
									target=target.concat(Character.toString(arclist[index2].charAt(loc)));
								loc++;
							}
							//System.out.println("Target 2= "+target);
							firstplacelist[firstplacelistindex]=target;
							firstplacelistindex++;
							break;
						}
						index2++;
					}
				}
				}
				index1++;
			}
			k=0;
			while(k<firstplacelistindex) {
				if((k+1)==firstplacelistindex)
					prop=prop.concat("AF(#"+firstplacelist[k]+">0)");
				else
					prop=prop.concat("AF(#"+firstplacelist[k]+">0) && ");
				k++;
			}
			bw2.write("Type = Liveness");
			bw2.newLine();
			bw2.write("Category = Initiation");
			bw2.newLine();
			bw2.write("Expected Output = True");
			bw2.newLine();
			bw2.write("Output = False Inference = Tasks obstructed to initiate");
			bw2.newLine();
			bw2.write(prop);
			bw2.newLine();
			bw2.newLine();
			bw2.newLine();
			bw3.write("Property: "+ prop);
			bw3.newLine();
			bw3.write("Output:");
			bw3.newLine();
			bw3.write("Trace:");
			bw3.newLine();
			
			//CTL property to checking blocking of tasks--interdependence checking
			
			k=0;
			prop="";
			wflag=0;
			while(k<finalplacelistindex) {
				int j=k+1;
				while(j!=finalplacelistindex) {
			
					prop="E(#"+finalplacelist[k]+"==0 U #"+finalplacelist[j]+"!=0)";
					if(wflag==0) {
						bw2.write("Type = Blocking");
						bw2.newLine();
						bw2.write("Category = Tasks Interdependence");
						bw2.newLine();
						bw2.write("Expected Output = False");
						bw2.newLine();
						bw2.write("Output = True Inference = Tasks blocking exists");
						bw2.newLine();
						wflag=1;
					}
						bw2.write(prop);
						bw2.newLine();
						bw2.newLine();
						bw2.newLine();
						bw3.write("Property: "+ prop);
						bw3.newLine();
						bw3.write("Output:");
						bw3.newLine();
						bw3.write("Trace:");
						bw3.newLine();
				
				j++;
			}
				k++;
			}
			bw2.close();
			bw3.close();
			}catch(IOException e) {
				
			}
	}
	public static void process_CTL_result() {
		String[][] propread=new String[100][4];
		String[][] propoutput=new String[100][2];
		int index1=0, index2=0;
		try {
		FileReader fread1= new FileReader(fileCTLoutput);
		//System.out.println("Done");
		FileReader fread2= new FileReader(fileCTL);
		int i=0;
		char c;
		String temp="";
		while((i=fread2.read())!=-1) {
			temp="";
			c=(char)i;
			temp=temp.concat(Character.toString(c));
			while((i=fread2.read())!=10) {
				c=(char)i;
				temp=temp.concat(Character.toString(c));
			}
			//Check for property beginning
			if(temp.contains("Type")) {
				if(temp.contains("Deadlock"))
					propread[index1][1]="Deadlock";
				else if(temp.contains("Liveness"))
					propread[index1][1]="Liveness";
				else if(temp.contains("Blocking"))
					propread[index1][1]="Blocking";
				else if(temp.contains("Boundedness"))
					propread[index1][1]="Boundedness";
				//read category
				
				while((i=fread2.read())!=10) {
				}
				//read expected output
				temp="";
				while((i=fread2.read())!=10) {
					c=(char)i;
					if(i!=13)
						temp=temp.concat(Character.toString(c));
				}
				if(temp.contains("true")|| temp.contains("True"))
					propread[index1][2]="true";
				if(temp.contains("false")|| temp.contains("False"))
					propread[index1][2]="false";
				//read output and inference
				temp="";
				while((i=fread2.read())!=10) {
					c=(char)i;
					if(i!=13)
						temp=temp.concat(Character.toString(c));
				}
				int j= temp.indexOf("Inference");
				int len=temp.length();
				j=j+12;
				String temp2="";
				while(j<len) {
					temp2=temp2.concat(Character.toString(temp.charAt(j)));
					j++;
				}
				propread[index1][3]=temp2;
				//read the property
				temp="";
				while((i=fread2.read())!=10) {
					c=(char)i;
					if(i!=13)
						temp=temp.concat(Character.toString(c));
				}
				propread[index1][0]=temp;
				index1++;
			}
		}
		int k=0;
		
		fread2.close();
		while((i=fread1.read())!=-1) {
			temp="";
			c=(char)i;
			temp=temp.concat(Character.toString(c));
			while((i=fread1.read())!=10) {
				c=(char)i;
				if(i!=13)
					temp=temp.concat(Character.toString(c));
			}
			//Check for property beginning
			if(temp.contains("Property")) {
				int j= temp.indexOf("Property");
				int len=temp.length();
				String temp2="";
				j=j+10;
				int first=0;
				while(j<len) {
					if(temp.charAt(j)==' ' && first==0) {
						first=1;
					}
					else if(temp.charAt(j)!=' ' && first==0) {
						temp2=temp2.concat(Character.toString(temp.charAt(j)));
						j++;
						first=1;
					}
					else {
						temp2=temp2.concat(Character.toString(temp.charAt(j)));
						j++;
					}
						
				}
				propoutput[index2][0]=temp2;
				//read the output
				temp="";
				while((i=fread1.read())!=10) {
					c=(char)i;
					if(i!=13)
						temp=temp.concat(Character.toString(c));
				}
				 j= temp.indexOf("Output");
					len=temp.length();
					temp2="";
					j=j+8;
					first=0;
					while(j<len) {
						if(temp.charAt(j)==' ' && first==0) {
							first=1;
						}
						else if(temp.charAt(j)!=' ' && first==0) {
							temp2=temp2.concat(Character.toString(temp.charAt(j)));
							j++;
							first=1;
						}
						else {
							temp2=temp2.concat(Character.toString(temp.charAt(j)));
							j++;
						}
							
					}
					propoutput[index2][1]=temp2;
				index2++;
			}
		}
		
		fread1.close();
		
		//Compare which property have failed-
		int p=0, q=0;
		while(p<index1) {
			String prop= propread[p][0];
			String category= propread[p][1];
			String expoutput=propread[p][2];
			String inference=propread[p][3];
			//System.out.println("Prop = "+prop +" category = "+category+" ExpOutput = "+expoutput);
			q=0;
			while(q<index2) {
				if(prop.compareTo(propoutput[q][0])==0)
					break;
				q++;
			}
			if(propread[p][2].compareTo(propoutput[q][1])==0) {
				System.out.println(" Property "+ prop +" Satisfied. No additional constraints are required!");
			}
			else {
				String cat= propread[p][1];
				String[] tracerecord=new String[100];
				int traceindex=0;
				//System.out.println(" Property "+ prop +" Not Satisfied. Additional constraints are required!");
				//read the trace
				fread1= new FileReader(fileCTLoutput);
				while((i=fread1.read())!=-1) {
					//System.out.println("File reading");
					temp="";
					c=(char)i;
					temp=temp.concat(Character.toString(c));
					while((i=fread1.read())!=10) {
						c=(char)i;
						if(i!=13)
							temp=temp.concat(Character.toString(c));
					}
					//Check for property beginning
					if(temp.contains("Property")) {
						//Extract the property
						int j= temp.indexOf("Property");
						int len=temp.length();
						String temp2="";
						j=j+10;
						int first=0;
						while(j<len) {
							if(temp.charAt(j)==' ' && first==0) {
								first=1;
							}
							else if(temp.charAt(j)!=' ' && first==0) {
								temp2=temp2.concat(Character.toString(temp.charAt(j)));
								j++;
								first=1;
							}
							else {
								temp2=temp2.concat(Character.toString(temp.charAt(j)));
								j++;
							}
								
						}
						propoutput[index2][0]=temp2;
						if(temp2.compareTo(prop)==0) {
							//read the output
							//System.out.println("Property Matched");
							while((i=fread1.read())!=10) {
							}
							//read trace
							while((i=fread1.read())!=10) {
							}
							//read lines
							int flag=0;
							
							traceindex=0;
							while(flag==0) {
								temp="";
								while((i=fread1.read())!=10) {
									c=(char)i;
									temp=temp.concat(Character.toString(c));
								}
								if(!temp.contains("Done")) {
								while((i=fread1.read())!=10) {
									c=(char)i;
									temp=temp.concat(Character.toString(c));
								}
								tracerecord[traceindex]=temp;
								traceindex++;
								}
								
								if(temp.contains("Done"))
									flag=1;
								else {
									temp="";
									while((i=fread1.read())!=10) {
										c=(char)i;
										temp=temp.concat(Character.toString(c));
									}
									if(temp.contains("Done")) {
										while((i=fread1.read())!=10) {
											if(i==-1)
												break;
										}
										flag=1;
									}
								}
								
							}
							break;
						}
						
					
					}
				}
				//System.out.println("File Reading Complete");
				fread1.close();
				int tr=0;
				int d1=0, d2=0;
				System.out.println("Trace index"+traceindex);
				while(tr<traceindex) {
					if(expoutput.compareTo("false")==0) {
						//System.out.println("Trace Record false");
						if(category.compareTo("Deadlock")==0) {
						//	System.out.println("Trace Record Deadlock");
						if(tracerecord[tr].contains("satisfies") || tracerecord[tr].contains("Satisfies")) {
							
							if((tracerecord[tr].contains("obstruct") || tracerecord[tr].contains("Obstruct") || tracerecord[tr].contains("onmove") || tracerecord[tr].contains("OnMove") || tracerecord[tr].contains("Obstacle") || tracerecord[tr].contains("obstacle")) && d1==0) {
									System.out.println("Add additional constraint for each task initiation");
									System.out.println("Add FR sub step- Set Start task ");
									System.out.println("Add FR sub step- Wait for obstruction clearance");
									System.out.println("Add FR sub step - Reinitaite start task if failed to start within alpha and beta time units.");
									System.out.println("Add NFR constraint : Response Time -max= alpha, min= beta, mostlikely=gamma");
									d1=1;
								}
							else if((!tracerecord[tr].contains("obstruct") || !tracerecord[tr].contains("Obstruct") || !tracerecord[tr].contains("onmove") || !tracerecord[tr].contains("OnMove")) && d2==0) {
								System.out.println("Additional constraint");
								System.out.println("Increase robot instance for parallel task execution");
								d2=1;
								}
							}
						}
						else if(category.compareTo("Boundedness")==0) {
							System.out.println("Add additional constraint for each common task initiation");
							System.out.println("Add FR sub step- Add tasks to queue");
							System.out.println("Modify NFR constraint : Response Time -max= alpha, min= beta, mostlikely=gamma");
							break;
						}
						else if(category.compareTo("Blocking")==0) {
							System.out.println("Add additional constraint- Tasks cannot be initiated in parallel ");
							System.out.println("Add communication message between nodes");
							System.out.println("Modify NFR constraint : Efficiency -max= alpha, min= beta, mostlikely=gamma");
							break;
						}
						
					}
					else if(expoutput.compareTo("true")==0 && inference.contains("initiate")) {
						if(tracerecord[tr].contains("does not satisfy")) {
						if((tracerecord[tr].contains("obstruct") || tracerecord[tr].contains("Obstruct") || tracerecord[tr].contains("onmove") || tracerecord[tr].contains("OnMove")) && d1==0) {
							System.out.println("Add additional constraint for each task initiation. Tasks not initiated in parallel");
							System.out.println("Add FR sub step- Wait for peers at start.");
							System.out.println("Add NFR constraint : Response Time -max= alpha, min= beta, mostlikely=gamma");
							System.out.println("Add FR sub step - Reinitaite start task if failed to start within alpha and beta time units.");
							d1=1;
						}
						else if((!tracerecord[tr].contains("obstruct") || !tracerecord[tr].contains("Obstruct") || !tracerecord[tr].contains("onmove") || !tracerecord[tr].contains("OnMove")) && d2==0) {
							System.out.println("Tasks not initiated in parallel");
							System.out.println("Add more robot instance for parallel execution");
							d2=1;
						}
						}
					}
					else if(expoutput.compareTo("true")==0 && inference.contains("complete")) {
						if(tracerecord[tr].contains("does not satisfy")) {
							if((tracerecord[tr].contains("obstruct") || tracerecord[tr].contains("Obstruct") || tracerecord[tr].contains("onmove") || tracerecord[tr].contains("OnMove")) && d1==0) {
								System.out.println("Add additional constraint for each task initiation. Tasks not initiated in parallel");
								System.out.println("Add FR sub step- Wait for peers to reach.");
								System.out.println("Add NFR constraint : Response Time -max= alpha, min= beta, mostlikely=gamma");
								break;
							}
							}
					}
					tr++;
				}
			}
			
			System.out.println();
			System.out.println();
			System.out.println();
			p++;
		}
		
		
		}catch(IOException e) {
			System.out.println("Unable to open file to read");
		}
	}
	public static void main(String[] args) {
		//create_file();
		//find_missing_elements();
		//group_places();
		//group_transitions();
		//group_arcs();
		//add_endlines();
		//CTL_generation();
		process_CTL_result();
	}
}
