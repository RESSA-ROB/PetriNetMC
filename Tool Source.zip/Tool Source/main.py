import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import subprocess
from test2 import*
import os
from tkinter import Listbox, SINGLE, END
from Petrinetgraphic import*

def on_enter(event):
    event.widget.config(bg='lightblue')

def on_leave(event):
    event.widget.config(bg='deep sky blue')

def load_file():
    global loaded_file_name;

    file_path = filedialog.askopenfilename()
    if file_path:
        loaded_file_name = file_path
        if (generate_button['state'] == tk.DISABLED):
           generate_button['state'] = tk.NORMAL
        if (viewpn_button['state'] == tk.DISABLED):
           viewpn_button['state'] = tk.NORMAL
        with open(file_path, 'r') as file:
            data = file.read()
        text_box1.config(state=tk.NORMAL)  # Enable the text box to insert text
        text_box1.delete(1.0, tk.END)
        text_box1.insert(tk.END, data)
        text_box1.config(state=tk.DISABLED)


def generate():
        #print(loaded_file_name)
        file_path='Generated.pnml'
        if loaded_file_name:
            jar_file_path = 'pnmlgen.jar'  # Update this with the path to your JAR file
            try:
                result = subprocess.run(['java', '-jar', jar_file_path, loaded_file_name], capture_output=True,
                                        text=True)
                output = result.stdout
                text_box2.config(state=tk.NORMAL)  # Enable the text box to insert text
                text_box2.delete(1.0, tk.END)
                with open(file_path, 'r') as file:
                    data = file.read()
                text_box2.insert(tk.END, data)
                text_box2.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
            except Exception as e:
                text_box2.config(state=tk.NORMAL)  # Enable the text box to insert text
                text_box2.delete(1.0, tk.END)
                text_box2.insert(tk.END, f"Error: {e}")
                text_box2.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
        else:
            text_box2.config(state=tk.NORMAL)  # Enable the text box to insert text
            text_box2.delete(1.0, tk.END)
            text_box2.insert(tk.END, "No file loaded.")
            text_box2.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
def draw_petrinet():
    plot_petrinet()

def load_content1():
        # Clear the content frame
        for widget in content_frame.winfo_children():
            widget.destroy()

        # Load new interface for Button 1
        load_file_button = tk.Button(content_frame,
                                     text="Load XMI File",
                                     command=load_file,
                                     activebackground="gray",
                                     activeforeground="white",
                                     anchor="center",
                                     bd=3,
                                     bg="deep sky blue",
                                     cursor="hand2",
                                     disabledforeground="gray",
                                     fg="black",
                                     font=("Calibri", 10),
                                     height=1,
                                     highlightbackground="black",
                                     highlightcolor="green",
                                     highlightthickness=2,
                                     justify="center",
                                     overrelief="raised",
                                     padx=10,
                                     pady=10,
                                     width=10,
                                     wraplength=100)

        #load_file_button.pack(padx=10, pady=10)
        load_file_button.place(x=380, y=10, width=100, height=50)

        load_file_button.bind("<Enter>", on_enter)
        load_file_button.bind("<Leave>", on_leave)
        #load_file_button = tk.Button(content_frame, text="Load File", command=load_file)
        #load_file_button.pack(pady=10)
        global generate_button
        generate_button = tk.Button(content_frame,
                                    text="Generate Petrinet",
                                    state=tk.DISABLED,
                                    command=generate,
                                    activebackground="gray",
                                    activeforeground="white",
                                    anchor="center",
                                    bd=3,
                                    bg="deep sky blue",
                                    cursor="hand2",
                                    disabledforeground="gray",
                                    fg="black",
                                    font=("Calibri", 10),
                                    height=1,
                                    highlightbackground="black",
                                    highlightcolor="green",
                                    highlightthickness=2,
                                    justify="center",
                                    overrelief="raised",
                                    padx=10,
                                    pady=10,
                                    width=10,
                                    wraplength=100)


        generate_button.place(x=780, y=10, width=100, height=50)
        generate_button.bind("<Enter>", on_enter)
        generate_button.bind("<Leave>", on_leave)
       # generate_button.pack(padx=10, pady=10)
       # #generate_button = tk.Button(content_frame, text="Generate", command=generate)
        #generate_button.pack(pady=10)
        global viewpn_button
        viewpn_button = tk.Button(content_frame,
                                    text="View Petrinet",
                                    state=tk.DISABLED,
                                    command=draw_petrinet,
                                    activebackground="gray",
                                    activeforeground="white",
                                    anchor="center",
                                    bd=3,
                                    bg="deep sky blue",
                                    cursor="hand2",
                                    disabledforeground="gray",
                                    fg="black",
                                    font=("Calibri", 10),
                                    height=1,
                                    highlightbackground="black",
                                    highlightcolor="green",
                                    highlightthickness=2,
                                    justify="center",
                                    overrelief="raised",
                                    padx=10,
                                    pady=10,
                                    width=10,
                                    wraplength=100)

        viewpn_button.place(x=980, y=10, width=100, height=50)
        viewpn_button.bind("<Enter>", on_enter)
        viewpn_button.bind("<Leave>", on_leave)
        global text_box1
        text_box1 = tk.Text(content_frame, height=30, width=50)
        text_box1.place(x=380, y=70)
        #text_box1.pack(pady=10)
        text_box1.config(state=tk.DISABLED)
        global text_box2
        text_box2 = tk.Text(content_frame, height=30, width=50)
        text_box2.place(x=780, y=70)
       # text_box2.pack(pady=10)
        text_box2.config(state=tk.DISABLED)

        labelf = tk.Label(content_frame, text="INSTRUCTIONS",font=("Calibri", 20))
        labelf.place(x=10, y=50)

        label = tk.Label(content_frame, text="1. Click on \"Load XMI file\" button to load an \n \n ATL transformation file (.xmi). \n \n The file is displayed in \n \n left content box. \n \n", font=("Calibri", 12))
        label.place(x=10, y=120)
        label2 = tk.Label(content_frame,
                         text="2. Click \"Generate Petrinet\" button to create \n \n an PNML specification (.pnml). \n \n The file is displayed in \n \n right content box. \n \n", font=("Calibri", 12))
        label2.place(x=10, y=280)

        label3 = tk.Label(content_frame,
                         text="3. Install GreatSPN tool in the system. \n \n \"https://github.com//greatspn//SOURCES/\" \n \n Load the tool by clicking \"Load GreatSPN\" \n \n button. \n \n Create a new project. \n \n Import Generated.pnml file within \n \n the newly created project.", font=("Calibri", 12))
        label3.place(x=10, y=450)


        tool_button = tk.Button(content_frame,
                                    text="Load GreatSPN",
                                    command=open_external_script,
                                    activebackground="gray",
                                    activeforeground="white",
                                    anchor="center",
                                    bd=3,
                                    bg="deep sky blue",
                                    cursor="hand2",
                                    disabledforeground="gray",
                                    fg="black",
                                    font=("Calibri", 10),
                                    height=1,
                                    highlightbackground="black",
                                    highlightcolor="green",
                                    highlightthickness=2,
                                    justify="center",
                                    overrelief="raised",
                                    padx=10,
                                    pady=10,
                                    width=10,
                                    wraplength=100)

        tool_button.place(x=380, y=600, width=100, height=50)
        tool_button.bind("<Enter>", on_enter)
        tool_button.bind("<Leave>", on_leave)


def open_external_script():
    try:
        # Running Notepad on Windows
        subprocess.run(['GreatSPN.exe'], check=True)
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while opening GreatSPN: {e}")


def show_text():
    sample_text = "This is the text to display."
    text_display_box.config(state=tk.NORMAL)  # Enable the text box to insert text
    text_display_box.delete(1.0, tk.END)
    text_display_box.insert(tk.END, sample_text)
    text_display_box.config(state=tk.DISABLED)  # Disable the text box to make it uneditable

def gen_ctl1():
    file_path= 'CTL.txt'
    if loaded_file_name:
        jar_file_path = 'ctlgen.jar'  # Update this with the path to your JAR file
        try:
            result = subprocess.run(['java', '-jar', jar_file_path, loaded_file_name], capture_output=True,
                                    text=True)
            output = result.stdout
            text_display_box.config(state=tk.NORMAL)  # Enable the text box to insert text
            text_display_box.delete(1.0, tk.END)
            with open(file_path, 'r') as file:
                data = file.read()
            text_display_box.insert(tk.END, data)
            text_display_box.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
        except Exception as e:
            text_display_box.config(state=tk.NORMAL)  # Enable the text box to insert text
            text_display_box.delete(1.0, tk.END)
            text_display_box.insert(tk.END, f"Error: {e}")
            text_display_box.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
    else:
        text_display_box.config(state=tk.NORMAL)  # Enable the text box to insert text
        text_display_box.delete(1.0, tk.END)
        text_display_box.insert(tk.END, "No file loaded.")
        text_display_box.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
    process_file()
        #available_listbox.delete(0, END)
    file_path = 'CTLlistF.txt'
    with open(file_path, 'r') as file:
        available_columns = file.read().splitlines()
    for item in available_columns:
        available_listbox.insert(END, item)
def gen_ctl2():
    inputspec=text_entry.get("1.0","end")
    display_text(inputspec)
    file_path = 'formulas.txt'
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"File {file_path} has been deleted.")
    else:
        print(f"File {file_path} does not exist.")

    output_file = 'formulas.txt'
    with open(output_file, 'a', encoding='utf-8') as file:
        file.write("\n \n Output 1 \n \n ");

    input_file = 'output1.txt'

    extract_formulas(input_file, output_file)

    with open(output_file, 'a', encoding='utf-8') as file:
        file.write("\n \n Output 2 \n \n ");

    input_file = 'output2.txt'
    extract_formulas(input_file, output_file)

    with open(output_file, 'a', encoding='utf-8') as file:
        file.write("\n \n Output 3 \n \n ");

    input_file = 'output3.txt'
    extract_formulas(input_file, output_file)

    print("File writing complete")
    content= read_file_to_string()
    print(content)
    max= majority_voting(content, inputspec)
    file_path = "output"+str(max)+".txt"
    with open(file_path, 'r') as file:
        data = file.read()
    text_display_box2.config(state=tk.NORMAL)  # Enable the text box to insert text
    text_display_box2.delete(1.0, tk.END)
    text_display_box2.insert(tk.END, data)
    text_display_box2.config(state=tk.DISABLED)

    process_file()
    available_listbox.delete(0, END)
    file_path = 'CTLlistF.txt'
    with open(file_path, 'r') as file:
        available_columns = file.read().splitlines()
    for item in available_columns:
        available_listbox.insert(END, item)
'''
def save_selected_to_file():
    selected_items = selected_listbox.get(0, END)
    file_path = 'selected_columns.txt'
    with open(file_path, 'w') as file:
        for item in selected_items:
            file.write(f"{item}\n")
    print(f"Selected columns saved to {file_path}")
'''
def gen_ctl3():
    #save_selected_to_file()
    determine_conflict()
    file_read = open('CTLconres.txt', 'r')

    # Read the entire content of the file
    response = file_read.read()
    text_display_box3.config(state=tk.NORMAL)  # Enable the text box to insert text
    text_display_box3.delete(1.0, tk.END)
    text_display_box3.insert(tk.END, response)
    text_display_box3.config(state=tk.DISABLED)



def load_content2():
    # Clear the content frame
    for widget in content_frame.winfo_children():
        widget.destroy()

        # Clear the content frame
        for widget in content_frame.winfo_children():
            widget.destroy()

        # Add a "Show" button and a text display box in content2
        show_button = tk.Button(content_frame,
                                    text="Derive CTL",
                                    command=gen_ctl1,
                                    activebackground="gray",
                                    activeforeground="white",
                                    anchor="center",
                                    bd=3,
                                    bg="deep sky blue",
                                    cursor="hand2",
                                    disabledforeground="gray",
                                    fg="black",
                                    font=("Calibri", 10),
                                    height=1,
                                    highlightbackground="black",
                                    highlightcolor="green",
                                    highlightthickness=2,
                                    justify="center",
                                    overrelief="raised",
                                    padx=10,
                                    pady=10,
                                    width=10,
                                    wraplength=100)

        show_button.place(x=380, y=15, width=80, height=40)
        show_button.bind("<Enter>", on_enter)
        show_button.bind("<Leave>", on_leave)
        #show_button.pack(padx=10, pady=10)
        #show_button = tk.Button(content_frame, text="Show", command=show_text)
        #show_button.pack(pady=5)

        global text_display_box
        text_display_box = tk.Text(content_frame, height=15, width=50)
        text_display_box.place(x= 380, y=60)
        #text_display_box.pack(pady=5)
        text_display_box.config(state=tk.DISABLED)  # Set the text box to be uneditable initially

        # Add a label and a text entry box in content2
        label = tk.Label(content_frame, text="Enter Requirement Text:")
        label.place(x=980, y=15)
        #label.pack(pady=5)

        global text_entry
        text_entry = tk.Text(content_frame, height=3, width=50)
       # text_entry.pack(pady=5)
        text_entry.place(x=880, y=60)
        generate_button2 = tk.Button(content_frame,
                                text="Map CTL",
                                command=gen_ctl2,
                                activebackground="gray",
                                activeforeground="white",
                                anchor="center",
                                bd=3,
                                bg="deep sky blue",
                                cursor="hand2",
                                disabledforeground="gray",
                                fg="black",
                                font=("Calibri", 10),
                                height=1,
                                highlightbackground="black",
                                highlightcolor="green",
                                highlightthickness=2,
                                justify="center",
                                overrelief="raised",
                                padx=10,
                                pady=10,
                                width=10,
                                wraplength=100)

        generate_button2.place(x=880, y=150, width=80, height=50)
        generate_button2.bind("<Enter>", on_enter)
        generate_button2.bind("<Leave>", on_leave)
        #generate_button.pack(padx=10, pady=10)

        global text_display_box2
        text_display_box2 = tk.Text(content_frame, height=8, width=50)
        text_display_box2.place(x=880, y=230)
        #text_display_box2.pack(pady=5)
        text_display_box2.config(state=tk.DISABLED)

        analyze_button = tk.Button(content_frame,
                                    text="Analyze CTL",
                                    command=gen_ctl3,
                                    activebackground="gray",
                                    activeforeground="white",
                                    anchor="center",
                                    bd=3,
                                    bg="deep sky blue",
                                    cursor="hand2",
                                    disabledforeground="gray",
                                    fg="black",
                                    font=("Calibri", 10),
                                    height=1,
                                    highlightbackground="black",
                                    highlightcolor="green",
                                    highlightthickness=2,
                                    justify="center",
                                    overrelief="raised",
                                    padx=10,
                                    pady=10,
                                    width=10,
                                    wraplength=100)

        analyze_button.place(x=590, y=330, width=80, height=40)
        analyze_button.bind("<Enter>", on_enter)
        analyze_button.bind("<Leave>", on_leave)

        global text_display_box3
        text_display_box3 = tk.Text(content_frame, height=30, width=60)
        text_display_box3.place(x=680, y=380)
        # text_display_box2.pack(pady=5)
        text_display_box3.config(state=tk.DISABLED)

        labelf = tk.Label(content_frame, text="INSTRUCTIONS", font=("Calibri", 20))
        labelf.place(x=10, y=50)

        label = tk.Label(content_frame,
                         text="1. Click on \"Derive CTL\" button to \n\n  view generic CTL properties. \n \n The content is displayed in left box. \n \n", font=("Calibri", 12))
        label.place(x=10, y=120)

        label2 = tk.Label(content_frame,
                          text="2. Enter natural language property \n\n in the \"Enter Requirements \n\n Text box\". \n \n ", font=("Calibri", 12))
        label2.place(x=10, y=250)

        label3 = tk.Label(content_frame,
                          text="3. Click on \"Map CTL button\". \n \n The right text box will display CTL \n \n formula for the property specified.\n \n ", font=("Calibri", 12))
        label3.place(x=10, y=360)

        label4 = tk.Label(content_frame,
                          text="4. Click on \"Analyze CTL\" button \n \n to identify conflicting properties.\n \n ", font=("Calibri", 12))
        label4.place(x=10, y=480)

        label4 = tk.Label(content_frame,
                          text="5. Feed the CTL properties in Great \n \n SPN tool to validate the petri-net. \n\n The results are to be used in \n \n next step.", font=("Calibri", 12))
        label4.place(x=10, y=580)

        labelsl = tk.Label(content_frame, text="CTL Property List")
        labelsl.place(x=350, y=340)

        '''
        add_button = tk.Button(content_frame,
                                   text="->",
                                   command=move_to_selected,
                                   activebackground="gray",
                                   activeforeground="white",
                                   anchor="center",
                                   bd=3,
                                   bg="deep sky blue",
                                   cursor="hand2",
                                   disabledforeground="gray",
                                   fg="black",
                                   font=("Calibri", 10),
                                   height=1,
                                   highlightbackground="black",
                                   highlightcolor="green",
                                   highlightthickness=2,
                                   justify="center",
                                   overrelief="raised",
                                   padx=10,
                                   pady=10,
                                   width=10,
                                   wraplength=100)

        add_button.place(x=500, y=450, width=60, height=30)
        add_button.bind("<Enter>", on_enter)
        add_button.bind("<Leave>", on_leave)
        remove_button = tk.Button(content_frame,
                               text="<-",
                               command=move_to_available,
                               activebackground="gray",
                               activeforeground="white",
                               anchor="center",
                               bd=3,
                               bg="deep sky blue",
                               cursor="hand2",
                               disabledforeground="gray",
                               fg="black",
                               font=("Calibri", 10),
                               height=1,
                               highlightbackground="black",
                               highlightcolor="green",
                               highlightthickness=2,
                               justify="center",
                               overrelief="raised",
                               padx=10,
                               pady=10,
                               width=10,
                               wraplength=100)

        remove_button.place(x=500, y=500, width=60, height=30)
        remove_button.bind("<Enter>", on_enter)
        remove_button.bind("<Leave>", on_leave)
        '''
        #master = tk()

        #scrollbary = Scrollbar(master)
        #scrollbarx = Scrollbar(master, orient=HORIZONTAL)
        global available_listbox;
        available_listbox=tk.Listbox(content_frame,
                                     height=60,
                                     width=60,
                                     selectmode=SINGLE,
                                     bg = "white",
                                     activestyle = 'dotbox',
                                     font = "Helvetica",
                                     fg = "black"
                                      )
        available_listbox.place(x=300, y=380, width=350, height=380)
        #scroll_x = tk.Scrollbar(content_frame, orient="horizontal", command=available_listbox.xview)
        #available_listbox.pack(side="top", fill="both", expand=True)
        #scroll_x.pack(side="bottom", fill="x")
        '''
        global selected_listbox;
        selected_listbox = tk.Listbox(content_frame,
                                       height=60,
                                       width=60,
                                       selectmode=SINGLE,
                                       bg="white",
                                       activestyle='dotbox',
                                       font="Helvetica",
                                       fg="black"
                                       )
        selected_listbox.place(x=580, y=380, width=200, height=380)
        '''
        #add_button = tk.Button(content_frame, text="→", command=move_to_selected)
        #add_button.place(x=480, y=380)
        #add_button.grid(row=0, column=1)

        #remove_button = tk.Button(content_frame, text="←", command=move_to_available)
        #remove_button.place(x=480, y=380)
        #remove_button.grid(row=1, column=1)


def load_result():
        global loaded_file_name2;
        file_path = filedialog.askopenfilename()
        if file_path:
            loaded_file_name2 = file_path
            with open(file_path, 'r') as file:
                data = file.read()
            text_display_box4.config(state=tk.NORMAL)  # Enable the text box to insert text
            text_display_box4.delete(1.0, tk.END)
            text_display_box4.insert(tk.END, data)
            text_display_box4.config(state=tk.DISABLED)

def gen_cons():
    file_path = 'Generated.pnml'
    if loaded_file_name2:
        jar_file_path = 'consgen.jar'  # Update this with the path to your JAR file
        try:
            result = subprocess.run(['java', '-jar', jar_file_path, loaded_file_name2], capture_output=True,
                                    text=True)
            output = result.stdout
            text_display_box5.config(state=tk.NORMAL)  # Enable the text box to insert text
            text_display_box5.delete(1.0, tk.END)
            with open(file_path, 'r') as file:
                data = file.read()
            text_display_box5.insert(tk.END, output)
            text_display_box5.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
        except Exception as e:
            text_display_box5.config(state=tk.NORMAL)  # Enable the text box to insert text
            text_display_box5.delete(1.0, tk.END)
            text_display_box5.insert(tk.END, f"Error: {e}")
            text_display_box5.config(state=tk.DISABLED)  # Disable the text box to make it uneditable
    else:
        text_display_box5.config(state=tk.NORMAL)  # Enable the text box to insert text
        text_display_box5.delete(1.0, tk.END)
        text_display_box5.insert(tk.END, "No file loaded.")
        text_display_box5.config(state=tk.DISABLED)  # Disable the text box to make it uneditable


def load_content3():
    # Clear the content frame
    for widget in content_frame.winfo_children():
        widget.destroy()

    load_button = tk.Button(content_frame,
                            text="Load CTL Result",
                            command=load_result,
                            activebackground="gray",
                            activeforeground="white",
                            anchor="center",
                            bd=3,
                            bg="deep sky blue",
                            cursor="hand2",
                            disabledforeground="gray",
                            fg="black",
                            font=("Calibri", 10),
                            height=1,
                            highlightbackground="black",
                            highlightcolor="green",
                            highlightthickness=2,
                            justify="center",
                            overrelief="raised",
                            padx=10,
                            pady=10,
                            width=10,
                            wraplength=100)

    load_button.place(x=380, y=15, width=100, height=50)
    load_button.bind("<Enter>", on_enter)
    load_button.bind("<Leave>", on_leave)
    # show_button.pack(padx=10, pady=10)
    # show_button = tk.Button(content_frame, text="Show", command=show_text)
    # show_button.pack(pady=5)

    global text_display_box4
    text_display_box4 = tk.Text(content_frame, height=20, width=50)
    text_display_box4.place(x=380, y=80)
    # text_display_box.pack(pady=5)
    text_display_box4.config(state=tk.DISABLED)  # Set the text box to be uneditable initially

    generate_button3= tk.Button(content_frame,
                                text="Generate Constraints",
                                command=gen_cons,
                                activebackground="gray",
                                activeforeground="white",
                                anchor="center",
                                bd=3,
                                bg="deep sky blue",
                                cursor="hand2",
                                disabledforeground="gray",
                                fg="black",
                                font=("Calibri", 10),
                                height=1,
                                highlightbackground="black",
                                highlightcolor="green",
                                highlightthickness=2,
                                justify="center",
                                overrelief="raised",
                                padx=10,
                                pady=10,
                                width=10,
                                wraplength=100)

    generate_button3.place(x=880, y=15, width=100, height=50)
    generate_button3.bind("<Enter>", on_enter)
    generate_button3.bind("<Leave>", on_leave)
    # generate_button.pack(padx=10, pady=10)

    global text_display_box5
    text_display_box5 = tk.Text(content_frame, height=20, width=50)
    text_display_box5.place(x=880, y=80)
    # text_display_box2.pack(pady=5)
    text_display_box5.config(state=tk.DISABLED)
    # Load content for button 3

    labelf = tk.Label(content_frame, text="INSTRUCTIONS", font=("Calibri", 20))
    labelf.place(x=10, y=50)

    label = tk.Label(content_frame, text="1. Click on \"Load CTL Result\" button to load \n\n the result file. \n\n The left box shows the contents of the file.\n\n", font=("Calibri", 12))
    #label.pack(pady=20)
    label.place(x=10, y=150)

    label2 = tk.Label(content_frame,
                      text="2. Click \"Generate Constraints\" button to \n\n generate the  constraints for satisfying \n\n  CTL properties. ", font=("Calibri", 12))
    label2.place(x=10, y=270)


# Create the main window
root = tk.Tk()
root.title("Dynamic Content Loader")
root.geometry("1500x1200")

# Create a frame for the side panel
side_panel = tk.Frame(root, width=200, bg="lightblue")
side_panel.pack(side="left", fill="y")

# Create buttons in the side panel
button1 = tk.Button(side_panel,
                   text="PNML Generation",
                   command=load_content1,
                   activebackground="gray",
                   activeforeground="white",
                   anchor="center",
                   bd=3,
                   bg="deep sky blue",
                   cursor="hand2",
                   disabledforeground="gray",
                   fg="black",
                   font=("Calibri", 10),
                   height=1,
                   highlightbackground="black",
                   highlightcolor="green",
                   highlightthickness=2,
                   justify="center",
                   overrelief="raised",
                   padx=10,
                   pady=10,
                   width=10,
                   wraplength=100)

#button1.pack(padx=10, pady=10)
button1.place(x=20, y=50, width=150, height=50)
button1.bind("<Enter>", on_enter)
button1.bind("<Leave>", on_leave)
#button1 = tk.Button(side_panel, text="Button 1", command=load_content1)
#button1.pack(pady=10, padx=10)

button2 = tk.Button(side_panel,
                   text="CTL Generation",
                   command=load_content2,
                   activebackground="gray",
                   activeforeground="white",
                   anchor="center",
                   bd=3,
                   bg="deep sky blue",
                   cursor="hand2",
                   disabledforeground="gray",
                   fg="black",
                   font=("Calibri", 10),
                   height=1,
                   highlightbackground="black",
                   highlightcolor="green",
                   highlightthickness=2,
                   justify="center",
                   overrelief="raised",
                   padx=10,
                   pady=10,
                   width=10,
                   wraplength=100)

#button2.pack(padx=10, pady=10)
button2.place(x=20, y=120, width=150, height=50)
button2.bind("<Enter>", on_enter)
button2.bind("<Leave>", on_leave)
#button2 = tk.Button(side_panel, text="Button 2", command=load_content2)
#button2.pack(pady=10, padx=10)

button3 = tk.Button(side_panel,
                   text="Constraint Generation",
                   command=load_content3,
                   activebackground="gray",
                   activeforeground="white",
                   anchor="center",
                   bd=3,
                   bg="deep sky blue",
                   cursor="hand2",
                   disabledforeground="gray",
                   fg="black",
                   font=("Calibri", 10),
                   height=1,
                   highlightbackground="black",
                   highlightcolor="green",
                   highlightthickness=2,
                   justify="center",
                   overrelief="raised",
                   padx=10,
                   pady=10,
                   width=10,
                   wraplength=100)

#button3.pack(padx=10, pady=10)
button3.place(x=20, y=190, width=150, height=50)
button3.bind("<Enter>", on_enter)
button3.bind("<Leave>", on_leave)
#button3 = tk.Button(side_panel, text="Button 3", command=load_content3)
#button3.pack(pady=10, padx=10)

# Create a frame for the content area
content_frame = tk.Frame(root, bg="white")
content_frame.pack(side="left", fill="both", expand=True)
labeli1 = tk.Label(content_frame,
                         text="1. Click on \"PNML Generation\" at first to generate petri net file.", font=("Calibri", 20))
labeli1.place(x=100, y=50)

labeli2 = tk.Label(content_frame,
                          text="2. Click on \"CTL Generation\" to generate temporal properties ", font=("Calibri", 20))
labeli2.place(x=100, y=150)

labeli3 = tk.Label(content_frame,
                          text="3. Click on \"Constraint Generation\" to view DSL modification", font=("Calibri", 20))
labeli3.place(x=100, y=250)
# Run the application
root.mainloop()
