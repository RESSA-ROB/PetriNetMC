import cohere
from langchain.document_loaders import PyPDFLoader
from together import Together
import re
from collections import Counter

client = Together(api_key='ADD Your Together AI API Key')
def display_text(inputspec):
    print("Executing")
    co = cohere.Client(api_key="ADD Your Cohere API Key")  # Replace with your actual API key
    loader = PyPDFLoader("CTL.pdf")
    documents = loader.load()

    loader2 = PyPDFLoader("temporal_logics.pdf")
    documents2 = loader2.load()

    # print(documents)
    #input = sys.argv[1]
    # input="when MugDelivery is done CoffeeMaking can start."
    # input="When Mug is delivered, then CoffeeMaking starts immediately."
    #input = "When mug is delivered and coffee making is done, then CoffeeDelivery must occur sometime in future"
    message = """
    ## Instructions
    You are an expert of writing Computational Tree logics (CTL) formula. Use the {context} below to enhance your knowledge of computational tree logics.
    Based on your understanding  write CTL for the Input Text below. Generate two formulas one based on 'A' quantifier and another based on 'E' quantifier.
    Write the formula using 'A' quantifier after writing 'Global Formula': on the same line.   Write the formula using 'E' quantifier after writing 'Existential Formula': on the same line. Do not provide any explanation.
    
    ##Context
    {context}

    ## Input Text
    {inp}

    """

    message = message.format(context=documents2, inp=inputspec)

    # get model response
    response = co.chat(
        message=message,
        model="command-r-plus",
        temperature=1
    )

    text = ""
    print("Cohere response")
    print(text)
    file_path = "output1.txt"
    file_path2="CTLlist.txt"
    with open(file_path, 'w', encoding='utf-8') as file:
       # file.write("Specification : "+inputspec+"\n \n \n")
        file.write("Command r+ Response \n\n \n");
        file.write(text)
    with open(file_path2, 'a', encoding='utf-8') as file:
        file.write(text)
        file.write("\n")

    response = client.chat.completions.create(
    model="meta-llama/Llama-3-70b-chat-hf",
    messages=[{"role": "user", "content": message}],
    )
    file_path = "output2.txt"
    print(response.choices[0].message.content)
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write("\n \n \n LLama-3 Response \n \n \n");
        file.write(response.choices[0].message.content)
    with open(file_path2, 'a', encoding='utf-8') as file:
        file.write(response.choices[0].message.content)
        file.write("\n")
    response = client.chat.completions.create(
        model="mistralai/Mixtral-8x22B-Instruct-v0.1",
        messages=[{"role": "user", "content": message}],
    )
    file_path = "output3.txt"
    print(response.choices[0].message.content)
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write("\n \n \n Mixtral Response \n \n \n");
        file.write(response.choices[0].message.content)
    with open(file_path2, 'a', encoding='utf-8') as file:
        file.write(response.choices[0].message.content)
        file.write("\n")

# Function to extract formulas and the following lines from the input file and write them to another file
def extract_formulas(input_file, output_file):
    with open(input_file, 'r') as infile, open(output_file, 'a') as outfile:
        lines = infile.readlines()
        formula_1 = ""
        formula_2 = ""
        next_line_1 = ""
        next_line_2 = ""
        for i in range(len(lines)):
            if "Global Formula" in lines[i] and formula_1=="":
                formula_1 = lines[i].strip()
                print("Global Formula = "+formula_1)
                if i + 1 < len(lines):
                    next_line_1 = lines[i + 1].strip()
            if "Existential Formula" in lines[i] and formula_2=="":
                formula_2 = lines[i].strip()
                print("Existential Formula = " + formula_2)
                if i + 1 < len(lines):
                    next_line_2 = lines[i + 1].strip()

        if formula_1:
            outfile.write(f" {formula_1}\n")
        if next_line_1:
            outfile.write(f"{next_line_1}\n")
        if formula_2:
            outfile.write(f" {formula_2}\n")
        if next_line_2:
            outfile.write(f"{next_line_2}\n")


def read_file_to_string():
    file_path="formulas.txt"
    with open(file_path, 'r') as file:
        content = file.read()
    return content

def majority_voting(content, inputspec):
    loader2 = PyPDFLoader("temporal_logics.pdf")
    documents2 = loader2.load()

    co = cohere.Client(api_key="ADD Your Cohere API Key")  # Replace with your actual API key
    message = """
        ## Instructions
        You are an expert of writing Computational Tree logics (CTL) formula. Use the {context} below to enhance your knowledge of computational tree logics.
        Based on your understanding and knowledge determine which among the 3 outputs in {output} is the best CTL for the Input Text below.
        Your response should only contain the output number. Do not provide any explanation.
        
        ##Context
        {context}
        
        ##Output
        {output}

        ## Input Text
        {inp}

        """

    message = message.format(context=documents2, output=content, inp=inputspec)

    # get model response
    response = co.chat(
        message=message,
        model="command-r-plus",
        temperature=1
    )
    text = response.text
    print(text)
    my_list = [0, 0, 0]
    if "3" in text:
        my_list[0] = 3
    if "2" in text:
        my_list[0] = 2
    if "1" in text:
        my_list[0] = 1


    response = client.chat.completions.create(
        model="meta-llama/Llama-3-70b-chat-hf",
        messages=[{"role": "user", "content": message}],
    )
    text= response.choices[0].message.content
   # print(text)
    if "3" in text:
        my_list[1]=3
    if "2" in text:
        my_list[1]=2
    if "1" in text:
        my_list[1]=1


    response = client.chat.completions.create(
        model="mistralai/Mixtral-8x22B-Instruct-v0.1",
        messages=[{"role": "user", "content": message}],
    )
    text= response.choices[0].message.content
   # print(text)
    if "3" in text:
        my_list[2] = 3
    if "2" in text:
        my_list[2] = 2
    if "1" in text:
        my_list[2] = 1
    counter = Counter(my_list)

    # Find the most common number and its count
    max_common_number, count = counter.most_common(1)[0]
    #print("Max is ")
    #print(max_common_number)
    return max_common_number


def process_file():
    print("Process File Executed!")
    input_file='CTLlist.txt'
    output_file='CTLlistF.txt'
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        lines = infile.readlines()

        count = 1

        for line in lines:
            # Remove 'Property:' and 'Formula' with regex
            #line = re.sub(r'Property:\s*', '', line)
            if("Property" in line):
                line=line.replace('Property:', '')
            elif("Global Formula:" in line):
                line = line.replace('Global Formula:', '')
            elif("Existential Formula:" in line):
                line = line.replace('Existential Formula:', '')
            #print("Line is "+line)
            #print("Line length is ")
            #print(len(line))
            if(len(line)!=1):
                outfile.write(f"{count}. {line.strip()}\n")
            #line = re.sub(r'Global Formula: \d+:\s*', '', line)
            #line = re.sub(r'Existential Formula: \d+:\s*', '', line)
            # Skip empty lines after removing keywords
            #if line.strip():
             #   outfile.write(f"{count}. {line.strip()}\n")
                count += 1

def fetch_result(ctl1data, ctl2data):
    loader2 = PyPDFLoader("temporal_logics.pdf")
    documents2 = loader2.load()

    message = """
                ## Instructions
                You are an expert of writing Computational Tree logics (CTL) formula. Use the {context} below to enhance your knowledge of computational tree logics.
                Based on your understanding and knowledge determine which if the two CTL formulas listed in {ctl1} and {ctl2} are conflicting. Respond only with formulas that are conflict. Else simply write No conflict. Explain the reason of conflict also.
                CTL formulas are conflicting when any one of the following conditions occur-
                1. If any two CTL properties have elements such that the precedence order of the elements in the two property are contradictory. For example
                AG (A -> AF B) and AG (B -> AF A)- In the first formula A occurs before B. In the second formula B occurs before A. Hence these two formulas are conflicting.
                2. If any two CTL properties have operators such that one suggests a strict immediate ordering and another suggests a relaxed ordering that is some time in future. For example-
                AG ( A -> AX(B)) and AG ( A -> AF(B)). In the first formula B must occur in the immediate next state along all paths. In the second formula 
                B can occur any time in future along all paths. This two formulas are conflicting.
                3. If any two CTL properties have different operators, but same element and conflicting precendences among the elements. For example-
                AG (A -> B ) and EF (B ->A). In the first formula A must occur before B. In the second formula B must occur A. Both formulas have differenr operators. This formulas are
                conflicting.

                However CTL properties may also conflict for reasons. 
                ##Context
                {context}

                ## Input Text
                {ctl1}
                {ctl2}

                """

    message = message.format(context=documents2, ctl1=ctl1data, ctl2=ctl2data)

    response = client.chat.completions.create(
        model="mistralai/Mixtral-8x22B-Instruct-v0.1",
        messages=[{"role": "user", "content": message}],
    )
    resp = response.choices[0].message.content
    text = "Mixtral Response\n "

    text = text + resp
    # print(text)
    response = client.chat.completions.create(
        model="meta-llama/Llama-3-70b-chat-hf",
        messages=[{"role": "user", "content": message}],
    )
    resp = response.choices[0].message.content
    text = text + "Llama Response\n"
    text = text + resp
    return text

def determine_conflict():
    file_path='CTLlistF.txt'
    with open(file_path, 'r') as file:
        data = file.readlines()
    i=0;
    ctl_array=[]
    for line in data:
        print("Line is ")
        print(line)
        ctl_array.append(line)
    i=0
    x=len(ctl_array)
    print("Length is ")
    print(x)
    while i<x:
        j=i+1
        while j<x:
            if(ctl_array[i]!= ctl_array[j]):
                response=fetch_result(ctl_array[i], ctl_array[j])
                file_path="CTLconres.txt"
                if i==0:
                    with open(file_path, 'w') as file:
                        file.write(f"{response}\n")
                elif i>0:
                    with open(file_path, 'w') as file:
                        file.write(f"{response}\n")
            j+=1
        i+=1

