import networkx as nx
import matplotlib.pyplot as plt
from pyvis.network import Network

def plot_petrinet():
    # Define places, transitions, and arcs
    with open('PlaceList.txt', 'r') as file:
        places = file.read().splitlines()
    #places = ['P1', 'P2', 'P3']
    #transitions = ['T1', 'T2']
    with open('TransitionList.txt', 'r') as file:
        transitions = file.read().splitlines()
    arcs = []
    with open('ArcList.txt', 'r') as file:
        for line in file:
            source, destination = line.split()
            arcs.append((source, destination))
    #arcs = [('P1', 'T1'), ('T1', 'P2'), ('P2', 'T2'), ('T2', 'P3')]

    # Create a directed graph
    petri_net = nx.DiGraph()

    # Add places and transitions as nodes
    petri_net.add_nodes_from(places, shape='o', color='white', size=1000)
    petri_net.add_nodes_from(transitions, shape='|', color='black', size=500)

    # Add arcs as edges
    petri_net.add_edges_from(arcs)

    # Position nodes
    pos = nx.spring_layout(petri_net, k=1, iterations=100)
    #pos = nx.kamada_kawai_layout(petri_net)
    #pos = {node: (i % 5, i // 5) for i, node in enumerate(petri_net.nodes())}

    # Draw places as circles
    nx.draw_networkx_nodes(petri_net, pos, nodelist=places, node_shape='o', node_size=1000, node_color='lightblue')
    # Draw transitions as rectangles
    nx.draw_networkx_nodes(petri_net, pos, nodelist=transitions, node_shape='s', node_size=500, node_color='gray')
    # Draw directed edges (arcs) with arrows
    nx.draw_networkx_edges(petri_net, pos, edgelist=arcs, arrowstyle='-|>', arrowsize=50, edge_color='black')

    # Draw labels
    nx.draw_networkx_labels(petri_net, pos, font_size=12, font_color='black')

    # Show plot
    plt.axis('off')
    plt.show()
